import requests
import json
import os
from requests_cache import CachedSession
from retry_requests import retry

def getDefinitions(word: str) -> str:
    """
    Get definitions for a word using the Dictionary API.
    Supports caching and retry logic for better reliability.
    """
    # Get configuration from environment variables
    api_timeout = int(os.getenv('API_TIMEOUT', '10'))
    cache_enabled = os.getenv('CACHE_ENABLED', 'true').lower() == 'true'

    # Setup session with caching if enabled
    if cache_enabled:
        session = CachedSession('dictionary_cache', expire_after=3600)  # Cache for 1 hour
    else:
        session = requests.Session()

    # Add retry logic
    session = retry(session, retries=3, backoff_factor=0.3)

    try:
        # Use the Dictionary API
        url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}"
        response = session.get(url, timeout=api_timeout)

        if response.status_code == 200:
            data = response.json()
            definitions = []

            # Extract definitions from all meanings
            for entry in data:
                for meaning in entry.get('meanings', []):
                    part_of_speech = meaning.get('partOfSpeech', '')
                    for definition in meaning.get('definitions', []):
                        def_text = definition.get('definition', '')
                        example = definition.get('example', '')

                        # Format the definition with part of speech
                        formatted_def = f"({part_of_speech}) {def_text}"
                        if example:
                            formatted_def += f" Example: {example}"
                        definitions.append(formatted_def)

            if definitions:
                return "\n\n".join(definitions)
            else:
                return "No definitions found in the response."
        else:
            return f"No definitions found. API returned status code: {response.status_code}"

    except requests.exceptions.Timeout:
        return "Request timed out. Please try again."
    except requests.exceptions.RequestException as e:
        return f"Error fetching definitions: {str(e)}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"