const tintColorLight = "#4F6BFF";

export default {
  light: {
    text: "#333333",
    background: "#F8F9FA",
    tint: tintColorLight,
    tabIconDefault: "#A0A0A0",
    tabIconSelected: tintColorLight,
    inputBackground: "#F1F3F4",
    cardBackground: "#FFFFFF",
    border: "#EEEEEE",
    error: "#E53935",
  },
};